package bg.tu_varna.sit.a2.f2231663.test;


enum Character {
    CALM, AGGRESSIVE
}
