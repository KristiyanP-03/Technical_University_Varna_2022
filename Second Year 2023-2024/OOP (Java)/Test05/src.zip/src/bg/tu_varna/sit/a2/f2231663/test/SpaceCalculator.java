package bg.tu_varna.sit.a2.f2231663.test;


interface SpaceCalculator {
    double calculateSpace();
}
