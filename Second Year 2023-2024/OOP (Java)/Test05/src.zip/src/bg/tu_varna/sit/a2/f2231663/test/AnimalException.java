package bg.tu_varna.sit.a2.f2231663.test;

class AnimalException extends Exception {
    public AnimalException(String message) {
        super(message);
    }
}
