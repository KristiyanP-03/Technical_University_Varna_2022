package bg.tu_varna.sit.a2.f2231663.test;

enum Color {
    WHITE, BLACK, STRIPED, BICOLOR, TRICOLOR
}
