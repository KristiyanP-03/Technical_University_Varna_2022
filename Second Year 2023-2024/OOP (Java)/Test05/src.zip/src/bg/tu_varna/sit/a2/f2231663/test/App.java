package bg.tu_varna.sit.a2.f2231663.test;

public class App {
    public static void main(String[] args) {

    }
}
