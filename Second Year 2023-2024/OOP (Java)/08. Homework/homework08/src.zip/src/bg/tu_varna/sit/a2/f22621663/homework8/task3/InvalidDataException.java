package bg.tu_varna.sit.a2.f22621663.homework8.task3;

class InvalidDataException extends Exception {
    public InvalidDataException(String message) {
        super(message);
    }
}

