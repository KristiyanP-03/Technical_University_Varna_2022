package bg.tu_varna.sit.a2.f22621663.homework8.task2;

interface Commission {
    double calculateCommission();
}