package bg.tu_varna.sit.a2.f22621663.homework8.task2;

public enum ParkingLot {
    noParkingLot, onePlaceForRent, onePlaceForSale, twoPlacesForRent, twoPlacesForSale,
    placesForRent, placesForSale
}