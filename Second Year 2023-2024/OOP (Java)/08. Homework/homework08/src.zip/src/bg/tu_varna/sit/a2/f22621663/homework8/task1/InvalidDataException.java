package bg.tu_varna.sit.a2.f22621663.homework8.task1;

class InvalidDataException extends Exception {
    public InvalidDataException(String message) {
        super(message);
    }
}
