package bg.tu_varna.sit.a2.f22621663.homework8.task4;

class FishList {
    private Fish[] fishes;

    public FishList(Fish[] fishes) {
        this.fishes = fishes;
    }
}