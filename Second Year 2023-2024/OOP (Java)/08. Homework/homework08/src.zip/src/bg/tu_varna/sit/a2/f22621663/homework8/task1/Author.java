package bg.tu_varna.sit.a2.f22621663.homework8.task1;

class Author {
    String firstName;
    String lastName;
    String country;

    public Author(String firstName, String lastName, String country) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.country = country;
    }


    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}