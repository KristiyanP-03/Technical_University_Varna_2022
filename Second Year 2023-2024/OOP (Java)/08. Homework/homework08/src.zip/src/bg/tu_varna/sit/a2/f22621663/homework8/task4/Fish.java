package bg.tu_varna.sit.a2.f22621663.homework8.task4;

class Fish {
    protected String name;
    protected double quantity;

    public Fish(String name, double quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}
