package bg.tu_varna.sit.a2.f22621663.homework10.task3;

interface Competency {
    boolean hasCompetence();
}
