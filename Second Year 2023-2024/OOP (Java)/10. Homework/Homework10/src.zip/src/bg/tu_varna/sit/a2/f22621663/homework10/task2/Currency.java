package bg.tu_varna.sit.a2.f22621663.homework10.task2;

enum Currency {
    BGN, USD, EUR, GBP
}
