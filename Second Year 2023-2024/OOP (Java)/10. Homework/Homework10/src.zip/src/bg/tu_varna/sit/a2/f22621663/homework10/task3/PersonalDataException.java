package bg.tu_varna.sit.a2.f22621663.homework10.task3;

class PersonalDataException extends Exception {
    public PersonalDataException(String message) {
        super(message);
    }
}
