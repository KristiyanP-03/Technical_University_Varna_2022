package bg.tu_varna.sit.a2.f22621663.homework10.task5;


enum AcademicPosition {
    Assistant, ChiefAssistant, Lecturer, SeniorLecturer, AssociateProfessor, Professor
}
