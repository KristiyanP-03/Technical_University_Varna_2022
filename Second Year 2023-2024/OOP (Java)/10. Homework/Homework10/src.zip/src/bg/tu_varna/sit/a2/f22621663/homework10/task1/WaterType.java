package bg.tu_varna.sit.a2.f22621663.homework10.task1;

enum WaterType {
    MINERAL,
    TABLE,
    SPRING,
    SODA
}
