package bg.tu_varna.sit.a2.f22621663.kontrl3.test;

public class App {
    public static void main(String[] args) {
        Address address1 = new Address("к1", "у1", 1);
        Address address2 = new Address("к2", "у2", 2);



        Property[] properties = {
                new Apartment(address1, 2000, 100000, 80, 2),
                new House(address2, 1998, 150000, 120, 300)
        };



        City city = new City(properties);


        double totalTaxes = city.calculateAllTaxes();
        System.out.println("Данъци: " + totalTaxes);


        Address maxPriceAddress = city.getMaxPricePropertyAddress();
        System.out.println("Най-висока продажна цена: " + maxPriceAddress);
    }
}
