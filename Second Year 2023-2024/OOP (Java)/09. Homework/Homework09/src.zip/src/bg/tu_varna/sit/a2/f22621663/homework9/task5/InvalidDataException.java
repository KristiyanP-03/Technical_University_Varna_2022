package bg.tu_varna.sit.a2.f22621663.homework9.task5;

class InvalidDataException extends RuntimeException {
    public InvalidDataException(String message) {
        super(message);
    }
}
