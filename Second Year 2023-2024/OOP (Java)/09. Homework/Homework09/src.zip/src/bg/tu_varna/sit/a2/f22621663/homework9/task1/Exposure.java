package bg.tu_varna.sit.a2.f22621663.homework9.task1;

enum Exposure {
    SEA_VIEW, PARK_VIEW
}
