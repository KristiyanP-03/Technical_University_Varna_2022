package bg.tu_varna.sit.a2.f22621663.homework9.task4;

enum Exposition {
    SOUTH, WEST, SOUTHWEST, NORTH, EAST, NORTHEAST, NORTHWEST, SOUTHEAST
}
