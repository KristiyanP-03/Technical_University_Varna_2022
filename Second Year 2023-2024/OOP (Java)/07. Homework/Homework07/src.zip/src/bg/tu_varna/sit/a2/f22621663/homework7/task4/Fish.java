package bg.tu_varna.sit.a2.f22621663.homework7.task4;

public abstract class Fish {
    String name;
    double quantity;

    public Fish(String name, double quantity) {
        this.name = name;
        this.quantity = quantity;
    }
}
