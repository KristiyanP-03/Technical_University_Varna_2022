package bg.tu_varna.sit.a2.f22621663.homework7.task5;

public interface Serving {
    void serve(int units);
}
