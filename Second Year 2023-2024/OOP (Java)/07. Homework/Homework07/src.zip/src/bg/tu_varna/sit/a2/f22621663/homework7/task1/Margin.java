package bg.tu_varna.sit.a2.f22621663.homework7.task1;

interface Margin {
    double calculateMargin();
}