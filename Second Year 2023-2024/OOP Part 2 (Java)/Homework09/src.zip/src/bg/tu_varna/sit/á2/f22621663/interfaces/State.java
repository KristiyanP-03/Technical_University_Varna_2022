package bg.tu_varna.sit.а2.f22621663.interfaces;

public interface State {
    void pressOnButton();
    void pressOffButton();
    void pressChannelUp();
    void pressChannelDown();
    void pressVolumeUp();
    void pressVolumeDown();
}

