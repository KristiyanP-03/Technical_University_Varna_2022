package bg.tu_varna.sit.а2.f22621663.interfaces;

public interface Command {
    void execute();
}
