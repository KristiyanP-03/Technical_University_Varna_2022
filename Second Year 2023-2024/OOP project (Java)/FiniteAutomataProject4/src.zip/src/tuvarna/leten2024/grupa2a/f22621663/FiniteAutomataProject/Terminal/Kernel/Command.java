package tuvarna.leten2024.grupa2a.f22621663.FiniteAutomataProject.Terminal.Kernel;


public interface Command {
    void execute(String[] args);
}

